"""Profile-scoped Harness integration; private backups, explicit plans, no client activation."""
import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import uuid

from app_paths import bundled, state_location
from state_install import initialized, _sync_directory

START = '# BEGIN REPRISE MANAGED INTEGRATION'
END = '# END REPRISE MANAGED INTEGRATION'
DOCS = ('REPRISE-AGENTS.template.md', 'CODEX-EXECUTION-CONTRACT.md', 'ASI1-ORCHESTRATOR.template.md', 'ASI1-ORCHESTRATION-CONTRACT.md', 'HANDOFF-CONTRACT.md', 'HARNESS-ROLES-CONTRACT.md', 'DELEGATION-PERSISTENCE.md', 'QUOTA-KNOWLEDGE.md', 'HARNESS-SUPERVISION-ARCHITECTURE.md', 'HARNESS-INTEGRATION.md', 'CLARIFICATION-CONTRACT.md')
OBSERVE = ('reprise_backends', 'reprise_requests', 'reprise_quotas')
DELEGATE = ('reprise_delegate', 'reprise_followup', 'reprise_reconcile')


def digest(value):
    return hashlib.sha256(value).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2) + '\n'


def file_hash(path):
    if path.is_symlink():
        raise ValueError(f'Lien symbolique non géré : {path}')
    if path.exists() and not path.is_file():
        raise ValueError(f'Fichier régulier requis : {path}')
    return digest(path.read_bytes()) if path.exists() else None


def atomic(path, text):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.NamedTemporaryFile(mode='w', dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
        try:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    try:
        temporary.replace(path)
        _sync_directory(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def context(home, profile):
    if not re.fullmatch(r'[A-Za-z0-9_-]+', profile):
        raise ValueError('Nom de profil invalide.')
    home = Path(home).expanduser().absolute()
    if home.is_symlink():
        raise ValueError('Dossier Harness symbolique refusé.')
    home = home.resolve(strict=True)
    folder = home / 'profiles' / profile
    for path in (home, home / 'profiles', folder, folder / '.reprise'):
        if path.is_symlink():
            raise ValueError('Profil ou dossier de gestion symbolique refusé.')
    if not folder.is_dir() or not (folder / 'cordis.patch.yml').is_file():
        raise ValueError('Profil Harness existant requis (cordis.patch.yml). Aucun profil créé automatiquement.')
    return home, folder, folder / '.reprise'


def safe_profile_path(path, folder):
    if '..' in path.parts or not path.is_relative_to(folder):
        raise ValueError('Chemin géré hors du profil.')
    for entry in [path] + list(path.parents):
        if entry == folder.parent:
            break
        if entry.is_symlink():
            raise ValueError(f'Chemin géré symbolique : {entry}')


def manifest(managed):
    path = managed / 'managed.json'
    if not path.exists():
        return None
    file_hash(path)
    value = json.loads(path.read_text())
    if not isinstance(value, dict) or value.get('format') != 1:
        raise ValueError('Manifeste d’intégration incompatible.')
    return value


def read_journal(path):
    if file_hash(path) is None:
        return {}
    value = json.loads(path.read_text())
    if not isinstance(value, dict) or value.get('format') != 1 or value.get('status') not in ('pending', 'completed'):
        raise ValueError('Journal incompatible ou incomplet ; conserver les sauvegardes et réconcilier.')
    return value


def split_block(text):
    if text.count(START) != text.count(END) or text.count(START) > 1:
        raise ValueError('Bloc Reprise ambigu ; réconciliation requise.')
    if START not in text:
        return text, None
    match = re.search(r'(?m)^' + re.escape(START) + r'\n.*?^' + re.escape(END) + r'(?:\n|$)', text, re.S)
    if match is None:
        raise ValueError('Délimiteurs Reprise invalides.')
    return text[:match.start()] + text[match.end():], match.group()


_BLOCK_REFUSAL = 'Bloc Reprise personnalisé ou non géré ; aucune réécriture.'
_BLOCK_ILLISIBLE = 'Bloc Reprise illisible ; réconciliation impossible.'


def block_entries(block_text):
    # Le bloc géré est du YAML minimal produit ici : une seule clé `insert`
    # portant le JSON des entries, en ligne ou ré-indenté sur les lignes suivantes.
    lines = block_text.splitlines()
    index = next((i for i, line in enumerate(lines) if re.match(r'^- insert:', line)), None)
    if index is None:
        raise ValueError(_BLOCK_ILLISIBLE)
    inline = lines[index][len('- insert:'):].strip()
    if inline:
        payload = inline
    else:
        collected = []
        indent = None
        for line in lines[index + 1:]:
            if not line.strip():
                continue
            if not line.startswith(' '):
                break
            if indent is None:
                indent = re.match(r' *', line).end()
            collected.append(line[indent:])
        payload = ' '.join(collected)
    try:
        entries = json.loads(payload)
    except json.JSONDecodeError:
        raise ValueError(_BLOCK_ILLISIBLE)
    if not isinstance(entries, list):
        raise ValueError(_BLOCK_ILLISIBLE)
    return entries


def _bridge_entries(release, state, tools, project, profile, managed, output_resume=False, output_resume_project=None, codex_workspace_write=False):
    program = release / 'Contents/Resources/runtime/bin/python3'
    args = ['-E', '-s', '-B', str(release / 'Contents/Resources/helpers/codex_expert_mcp.py'),
            '--project-root', project, '--state', state, '--tools', ','.join(tools)]
    if codex_workspace_write:
        args.append('--codex-workspace-write')
    entries = [
        {'id': 'reprise-codex-expert', 'name': '@deepseek-ai/dsh-mcp-client', 'config': {
            'transport': 'stdio', 'serverName': 'reprise_codex', 'command': str(program), 'args': args,
            'toolCallTimeoutMs': 330000, 'failOnStartupError': False, 'reconnect': {'enabled': False}}},
        {'id': 'reprise-skill-filesystem', 'name': '@deepseek-ai/dsh-skill-filesystem', 'config': {
            'providerName': 'reprise-' + profile, 'includeDefaultRoots': False,
            'customSkillDirs': [str(managed / 'skills')], 'watch': False}}]
    if output_resume:
        entries.append({'id': 'reprise-output-resume', 'name': str(release / 'Contents/Resources/helpers/harness-output-resume.cjs'),
                        'config': {'enabled': True, 'projectRoot': output_resume_project or project,
                                   'stateDirectory': str(Path(state) / 'harness-output-resume'),
                                   'maxConsecutive': 2}})
    return entries


def tree_files(root):
    result = {}
    for entry in sorted(root.rglob('*')):
        if entry.is_symlink():
            if not entry.resolve().is_relative_to(root.resolve()):
                raise ValueError('Lien de payload sortant.')
            result[str(entry.relative_to(root))] = {'symlink': os.readlink(entry)}
        elif entry.is_file():
            result[str(entry.relative_to(root))] = digest(entry.read_bytes())
    return result


def bundle_info(root):
    root = Path(root).resolve()
    helpers = root if bundled(root) else root / 'Reprise.app/Contents/Resources/helpers'
    payload = json.loads((helpers / 'payload-manifest.json').read_text())
    runtime = helpers.parent / 'runtime'
    runtime_manifest = json.loads((runtime / 'runtime-manifest.json').read_text())
    if not isinstance(payload.get('runtime'), dict):
        raise ValueError('Construire le bundle avec son runtime Python embarqué avant installation.')
    for name, expected in payload['files'].items():
        if Path(name).name != name:
            raise ValueError('Chemin de payload non supporté.')
        if file_hash(helpers / name) != expected:
            raise ValueError('Payload helpers modifié ; reconstruire le bundle.')
    actual = tree_files(runtime)
    actual.pop('runtime-manifest.json', None)
    if actual != runtime_manifest['files'] or not os.access(runtime / 'bin/python3', os.X_OK):
        raise ValueError('Runtime embarqué altéré ou incomplet.')
    native = helpers.parent / 'native-manifest.json'
    native_evidence = json.loads(native.read_text()) if native.exists() else {}
    for name, observed in native_evidence.get('binaries', {}).items():
        if file_hash(helpers.parent.parent / 'MacOS' / name) != observed['sha256']:
            raise ValueError('Binaire natif modifié ; reconstruire le bundle.')
    identity = digest(encoded({'payload': payload, 'runtime': runtime_manifest, 'native': native_evidence}).encode())
    return helpers, runtime, identity


def release_check(release):
    evidence = json.loads((release / 'release.json').read_text())
    actual = tree_files(release)
    actual.pop('release.json', None)
    if actual != evidence['files'] or not os.access(release / 'Contents/Resources/runtime/bin/python3', os.X_OK):
        raise ValueError('Copie installée altérée ; aucune exécution de ce release.')


def stage_release(helpers, runtime, release):
    if release.is_symlink() or release.parent.is_symlink():
        raise ValueError('Destination de release symbolique refusée.')
    if release.exists():
        release_check(release)
        return
    release.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.TemporaryDirectory(prefix='.release-', dir=release.parent) as temporary:
        stage = Path(temporary) / 'release'
        resources = stage / 'Contents/Resources'
        helper_target = resources / 'helpers'
        helper_target.mkdir(parents=True)
        payload = json.loads((helpers / 'payload-manifest.json').read_text())
        for name in list(payload['files']) + ['payload-manifest.json']:
            if Path(name).name != name:
                raise ValueError('Chemin de payload non supporté.')
            shutil.copyfile(helpers / name, helper_target / name)
        shutil.copytree(runtime, resources / 'runtime', symlinks=True)
        if (helpers.parent / 'native-manifest.json').is_file():
            shutil.copyfile(helpers.parent / 'native-manifest.json', resources / 'native-manifest.json')
        native = helpers.parent.parent / 'MacOS'
        if native.is_dir():
            shutil.copytree(native, stage / 'Contents/MacOS')
        atomic(stage / 'release.json', encoded({'format': 1, 'files': tree_files(stage)}))
        stage.rename(release)
        _sync_directory(release.parent)
    release_check(release)


def inspect(home, profile=None):
    home = Path(home).expanduser().absolute()
    profiles = sorted(p.name for p in (home / 'profiles').glob('*')
                      if re.fullmatch(r'[A-Za-z0-9_-]+', p.name) and p.is_dir() and not p.is_symlink() and (p / 'cordis.patch.yml').is_file())
    result = {'status': 'inspected', 'profiles': profiles, 'message': 'Inspection locale sans chargement du client. Interface vérifiée sur Harness 0.2.1-rc.2 ; version du client actif inconnue.'}
    if profile:
        _, _, managed = context(home, profile)
        old = manifest(managed)
        if old:
            result['project'] = old.get('project')
            result['output_resume'] = old.get('output_resume', False)
            result['output_resume_project'] = old.get('output_resume_project', old.get('project'))
            result['asi1_effort'] = old.get('asi1_effort', False)
            result['delegate'] = 'reprise_delegate' in old.get('tools', [])
            result['agent_role'] = old.get('agent_role', 'standard')
        result['codex_workspace_write'] = (old or {}).get('codex_workspace_write', False)
        journal = managed / 'operation.json'
        if journal.exists() or journal.is_symlink():
            data = read_journal(journal)
            if data.get('status') == 'pending':
                result['pending_plan'] = data['plan']
                result['backup'] = data.get('backup')
                result['message'] = 'Opération partielle conservée ; reprendre ce plan avant toute nouvelle modification.'
    return result


ASI1_START = '# BEGIN REPRISE ASI1 EFFORT'
ASI1_END = '# END REPRISE ASI1 EFFORT'
ASI1_PLUGIN_START = '# BEGIN REPRISE ASI1 EFFORT PLUGIN'
ASI1_PLUGIN_END = '# END REPRISE ASI1 EFFORT PLUGIN'
ASI1_ROUTES = ('asi-cloud', 'asi-cloud-planner')
ASI1_PLUGIN = 'asi1-orchestrator-effort.cjs'


def _indent(line):
    return len(line) - len(line.lstrip(' '))


def _route_bounds(lines, route):
    target = '      ' + route + ':'
    for index, line in enumerate(lines):
        if line.rstrip('\n') == target:
            end = index + 1
            while end < len(lines):
                raw = lines[end].rstrip('\n')
                if raw.strip() and _indent(raw) == 6 and not raw.lstrip().startswith('-'):
                    break
                end += 1
            return index, end
    return None


def _model_bounds(lines, start, end):
    for index in range(start, end):
        if lines[index].rstrip('\n') == '          - id: asi1':
            stop = index + 1
            while stop < end:
                raw = lines[stop].rstrip('\n')
                if raw.strip() and _indent(raw) == 10 and raw.lstrip().startswith('- '):
                    break
                stop += 1
            return index, stop
    return None


def _compat_bounds(lines, start, end):
    for index in range(start, end):
        if lines[index].rstrip('\n') == '        compat:':
            stop = index + 1
            while stop < end:
                raw = lines[stop].rstrip('\n')
                if raw.strip() and _indent(raw) <= 8:
                    break
                stop += 1
            return index, stop
    return None


def _marker_blocks(lines):
    blocks = []
    index = 0
    while index < len(lines):
        if lines[index].strip() == ASI1_START:
            stop = index + 1
            while stop < len(lines) and lines[stop].strip() != ASI1_END:
                stop += 1
            if stop == len(lines):
                raise ValueError('Bloc ASI1 sans délimiteur de fin ; réconciliation requise.')
            blocks.append((index, stop + 1))
            index = stop + 1
        else:
            index += 1
    return blocks


def _strip_asi1_blocks(text, expected):
    lines = text.splitlines(keepends=True)
    blocks = _marker_blocks(lines)
    if blocks:
        if expected is None:
            raise ValueError('Marqueurs ASI1 non gérés ; aucune réécriture.')
        observed = sorted(digest(''.join(lines[start:stop]).encode()) for start, stop in blocks)
        if observed != sorted(expected):
            raise ValueError('Bloc ASI1 personnalisé ; aucune réécriture.')
        for start, stop in reversed(blocks):
            del lines[start:stop]
    elif expected:
        raise ValueError('Bloc ASI1 géré absent ; réparation explicite requise.')
    return ''.join(lines)


def apply_asi1_effort(text, old, enable):
    """Add or remove only marker-owned ASI:One reasoning declarations."""
    expected = None
    if old and old.get('asi1_effort'):
        expected = old.get('asi1_effort_blocks', [])
    text = _strip_asi1_blocks(text, expected)
    if not enable:
        return text, [], False
    lines = text.splitlines(keepends=True)
    blocks = []
    preexisting = False
    direct = _route_bounds(lines, 'asi-cloud')
    if direct is None or _model_bounds(lines, *direct) is None:
        raise ValueError('Configuration ASI1 absente : route asi-cloud et modèle asi1 requis.')
    for route in ASI1_ROUTES:
        bounds = _route_bounds(lines, route)
        if bounds is None:
            continue
        start, end = bounds
        model = _model_bounds(lines, start, end)
        if model is None:
            continue
        model_start, model_end = model
        model_lines = lines[model_start:model_end]
        effort_names = [line for line in model_lines if line.strip().startswith('reasoningEfforts:')]
        if effort_names:
            if not any(line.strip().startswith('low:') for line in model_lines):
                raise ValueError(f'Route {route} : reasoningEfforts existant sans niveau low.')
            preexisting = True
        else:
            block = [
                '            ' + ASI1_START + '\n',
                '            reasoningEfforts:\n',
                '              low: low\n',
                '              medium: medium\n',
                '              high: high\n',
                '            ' + ASI1_END + '\n',
            ]
            anchor = next((i for i in range(model_start, model_end)
                           if lines[i].strip().startswith('maxTokens:')), model_start)
            lines[anchor + 1:anchor + 1] = block
            blocks.append(''.join(block))
        compat = _compat_bounds(lines, *_route_bounds(lines, route))
        if compat is None:
            route_end = _route_bounds(lines, route)[1]
            block = [
                '        compat:\n',
                '          ' + ASI1_START + '\n',
                '          supportsReasoningEffort: true\n',
                '          supportsDeveloperRole: false\n',
                '          ' + ASI1_END + '\n',
            ]
            lines[route_end:route_end] = block
            blocks.append(''.join(block))
        else:
            compat_start, compat_end = compat
            names = [line.strip().split(':', 1)[0] for line in lines[compat_start + 1:compat_end] if ':' in line]
            missing = []
            if 'supportsReasoningEffort' not in names:
                missing.append('          supportsReasoningEffort: true\n')
            elif not any(line.strip() == 'supportsReasoningEffort: true' for line in lines[compat_start + 1:compat_end]):
                raise ValueError(f'Route {route} : supportsReasoningEffort doit être true.')
            if 'supportsDeveloperRole' not in names:
                missing.append('          supportsDeveloperRole: false\n')
            elif not any(line.strip() == 'supportsDeveloperRole: false' for line in lines[compat_start + 1:compat_end]):
                raise ValueError(f'Route {route} : supportsDeveloperRole doit être false.')
            if missing:
                block = ['          ' + ASI1_START + '\n'] + missing + ['          ' + ASI1_END + '\n']
                lines[compat_end:compat_end] = block
                blocks.append(''.join(block))
            else:
                preexisting = True
    return ''.join(lines), sorted(digest(block.encode()) for block in blocks), preexisting


def _plugin_blocks(lines):
    blocks = []
    index = 0
    while index < len(lines):
        if lines[index].strip() == ASI1_PLUGIN_START:
            stop = index + 1
            while stop < len(lines) and lines[stop].strip() != ASI1_PLUGIN_END:
                stop += 1
            if stop == len(lines):
                raise ValueError('Bloc plugin ASI1 sans délimiteur de fin ; réconciliation requise.')
            blocks.append((index, stop + 1))
            index = stop + 1
        else:
            index += 1
    return blocks


def _strip_asi1_preset(text, expected):
    lines = text.splitlines(keepends=True)
    blocks = _plugin_blocks(lines)
    if blocks:
        if expected is None:
            raise ValueError('Marqueurs de preset ASI1 non gérés ; aucune réécriture.')
        observed = sorted(digest(''.join(lines[start:stop]).encode()) for start, stop in blocks)
        if observed != sorted(expected):
            raise ValueError('Preset ASI1 personnalisé ; aucune réécriture.')
        for start, stop in reversed(blocks):
            del lines[start:stop]
    elif expected:
        raise ValueError('Preset ASI1 géré absent ; réparation explicite requise.')
    return ''.join(lines)


def apply_asi1_preset(text, old, enable, plugin_path):
    """Insert or remove the preset-scoped plugin row with explicit ownership."""
    expected = None
    if old and old.get('asi1_effort'):
        expected = old.get('asi1_preset_blocks', [])
    text = _strip_asi1_preset(text, expected)
    if not enable:
        return text, [], False
    lines = text.splitlines(keepends=True)
    start = None
    base_indent = 0
    for index, line in enumerate(lines):
        match = re.match(r'^(\s*)- id: preset-asi1-orchestrator\s*$', line)
        if match:
            start, base_indent = index, len(match.group(1))
            break
    if start is None:
        raise ValueError('Preset asi1-orchestrator absent ; créer le preset avant l’option ASI1.')
    end = start + 1
    while end < len(lines):
        raw = lines[end].rstrip('\n')
        if raw.strip() and _indent(raw) <= base_indent and not raw.lstrip().startswith('#'):
            break
        end += 1
    plugins = next((index for index in range(start, end) if lines[index].strip() == 'plugins:'), None)
    if plugins is None or lines[plugins].strip() != 'plugins:':
        raise ValueError('Preset asi1-orchestrator sans liste plugins ; forme non prise en charge.')
    plugins_indent = _indent(lines[plugins])
    list_end = plugins + 1
    item_indent = None
    while list_end < end:
        raw = lines[list_end].rstrip('\n')
        if raw.strip() and _indent(raw) <= plugins_indent:
            break
        if item_indent is None and raw.lstrip().startswith('- '):
            item_indent = _indent(raw)
        list_end += 1
    if any(_indent(lines[index]) == item_indent
           and re.match(r'^\s*- id: asi1-orchestrator-effort\s*$', lines[index])
           for index in range(plugins + 1, list_end)):
        return ''.join(lines), [], True
    indent = ' ' * (item_indent if item_indent is not None else plugins_indent + 2)
    block = [
        indent + ASI1_PLUGIN_START + '\n',
        indent + '- id: asi1-orchestrator-effort\n',
        indent + '  name: ' + plugin_path + '\n',
        indent + '  config:\n',
        indent + '    effort: low\n',
        indent + '    providers:\n',
        indent + '      - asi-cloud\n',
        indent + '      - asi-cloud-planner\n',
        indent + '    models:\n',
        indent + '      - asi1\n',
        indent + ASI1_PLUGIN_END + '\n',
    ]
    lines[list_end:list_end] = block
    return ''.join(lines), [digest(''.join(block).encode())], False


def desired(root, home, profile, project, action, delegate=False, agent_role='standard', output_resume=False, output_resume_project=None, codex_workspace_write=False, asi1_effort=False):
    home, folder, managed = context(home, profile)
    old = manifest(managed)
    project = str(Path(project).expanduser().resolve(strict=True))
    if not Path(project).is_dir():
        raise ValueError('Projet autorisé : dossier existant requis.')
    if old and old.get('status') == 'installed' and action == 'remove' and old['project'] != project:
        raise ValueError('Projet sélectionné différent du projet géré ; inspecter le profil avant retrait.')
    config = folder / 'cordis.patch.yml'
    file_hash(config)
    original = config.read_bytes().decode('utf-8')
    base, block = split_block(original)
    base, asi1_blocks, asi1_preexisting = apply_asi1_effort(base, old, asi1_effort and action == 'install')
    base, asi1_preset_blocks, asi1_preset_preexisting = apply_asi1_preset(
        base, old, asi1_effort and action == 'install', str(managed / 'plugins' / ASI1_PLUGIN))
    mismatched_block = block is not None and (not old or old.get('status') != 'installed' or digest(block.encode()) != old.get('block_sha256'))
    # Réconciliation install uniquement : l'équivalence se juge sur les entries régénérées plus bas.
    if mismatched_block and action != 'install':
        raise ValueError(_BLOCK_REFUSAL)
    if any(token in base for token in ('reprise-codex-expert', 'reprise_codex', 'reprise-skill-filesystem', '# BEGIN REPRISE EXPERTISE')):
        raise ValueError('Ancienne intégration ou définition Reprise non gérée : réconciliation requise, aucun écrasement.')
    for relative, expected in (old or {}).get('managed_files', {}).items():
        path = folder / relative
        allowed = (managed / 'skills', managed / 'plugins')
        if Path(relative).is_absolute() or '..' in Path(relative).parts or not any(path.is_relative_to(directory) for directory in allowed):
            raise ValueError('Manifeste de fichiers gérés hors périmètre.')
        safe_profile_path(path, folder)
        if file_hash(path) not in (None, expected):
            raise ValueError(f'Fichier géré personnalisé : {path}. Sauvegarder et réconcilier avant modification.')
    meaningful = [line for line in base.splitlines() if line.strip() and not line.lstrip().startswith('#')]
    empty_array = len(meaningful) == 1 and re.fullmatch(r'\[\]\s*(?:#.*)?', meaningful[0].strip()) is not None
    if not empty_array and any(not line[0].isspace() and not (line.startswith('- ') or line == '-') for line in meaningful):
        raise ValueError('Forme du patch non prise en charge : liste YAML de patches ou [] attendue. Aucun changement.')
    resume_project = str(Path(output_resume_project or project).expanduser().resolve(strict=True))
    if not Path(resume_project).is_dir():
        raise ValueError('Projet de continuation : dossier existant requis.')
    files = {}
    reconciliation = None
    reconciled_from = None
    release = None
    state = str(state_location(root).absolute())
    if not bundled(root) and Path(state).resolve().is_relative_to(Path(root).resolve()):
        raise ValueError('Préparer un état indépendant du clone (ou utiliser le bundle) avant installation.')
    if action == 'install':
        if not initialized(Path(state)) and not (Path(state) / 'tasks.sqlite').is_file():
            raise ValueError('Préparer l’état Reprise avant installation ; aucun registre neuf implicite.')
        helpers, runtime, identity = bundle_info(root)
        release = Path(state).parent / 'integration-releases' / identity
        tools = OBSERVE + (DELEGATE if delegate else ())
        entries = _bridge_entries(release, state, tools, project, profile, managed,
                                  output_resume, resume_project, codex_workspace_write)
        if mismatched_block:
            try:
                parsed = block_entries(block)
            except ValueError:
                raise ValueError(_BLOCK_REFUSAL)
            if parsed != entries:
                raise ValueError(_BLOCK_REFUSAL)
            # Bloc reformatté équivalent : réécriture canonique tracée dans le manifeste.
            reconciled_from = digest(block.encode())
        new_block = START + '\n- insert: ' + json.dumps(entries, ensure_ascii=False) + '\n' + END + '\n'
        if reconciled_from:
            reconciliation = {'from_sha256': reconciled_from, 'to_sha256': digest(new_block.encode())}
        empty_before = (old or {}).get('empty_before')
        empty_after = (old or {}).get('empty_after')
        if empty_array:
            empty_before = base
            base = re.sub(r'(?m)^([ \t]*)\[\]([ \t]*(?:#[^\n]*)?)$', r'\1\2', base)
            empty_after = base
        files[config] = base + ('' if not base or base.endswith('\n') else '\n') + new_block
        skill_folder = managed / 'skills/reprise-delegation'
        skill = (helpers / 'reprise-delegation.md').read_text()
        skill += '\n\nInstalled scope metadata (data): ' + json.dumps({'profile': profile, 'project_root': project, 'enabled_tools': tools}, ensure_ascii=False) + '\nInspect actual tools and project_root before use.\n'
        if agent_role == 'coordinator':
            skill += '\n\n## Active operator-selected role: coordinator\nThis role is an assignment, not evidence of model capability. It does not grant inference permissions.\n'
            skill += (helpers / 'REPRISE-AGENTS.template.md').read_text()
        files[skill_folder / 'SKILL.md'] = skill
        for name in DOCS:
            files[skill_folder / name] = (helpers / name).read_text()
        if asi1_effort:
            files[managed / 'plugins' / ASI1_PLUGIN] = (helpers / ASI1_PLUGIN).read_text()
        owned = {str(path.relative_to(folder)): digest(text.encode()) for path, text in files.items() if path != config}
        next_manifest = {'format': 1, 'interface_validated_against': 'Harness 0.2.1-rc.2', 'status': 'installed', 'project': project, 'profile': profile,
                         'state': state, 'release': str(release), 'tools': list(tools),
                         'block_sha256': digest(new_block.encode()), 'managed_files': owned,
                         'empty_before': empty_before, 'empty_after': empty_after}
        if output_resume:
            next_manifest['output_resume'] = True
            next_manifest['output_resume_project'] = resume_project
        if asi1_effort:
            next_manifest['asi1_effort'] = True
            next_manifest['asi1_effort_blocks'] = asi1_blocks
            next_manifest['asi1_effort_preexisting'] = asi1_preexisting
            next_manifest['asi1_preset_blocks'] = asi1_preset_blocks
            next_manifest['asi1_preset_preexisting'] = asi1_preset_preexisting
        if codex_workspace_write:
            next_manifest['codex_workspace_write'] = True
        if reconciled_from:
            next_manifest['reconciled_from_sha256'] = reconciled_from
        elif old and 'reconciled_from_sha256' in old:
            # Preuve conservée : le manifeste régénéré doit rester identique au manifeste en place.
            next_manifest['reconciled_from_sha256'] = old['reconciled_from_sha256']
        if agent_role != 'standard':
            next_manifest['agent_role'] = agent_role
    else:
        if not old or old.get('status') != 'installed':
            return {}, {'release': None, 'state': state}, None
        if base == old.get('empty_after'):
            base = old['empty_before']
        elif not any(line.strip() and not line.lstrip().startswith('#') for line in base.splitlines()):
            base += ('' if not base or base.endswith('\n') else '\n') + '[]\n'
        files[config] = base
        for relative in old['managed_files']:
            files[folder / relative] = None
        next_manifest = {'format': 1, 'status': 'removed', 'project': project, 'profile': profile,
                         'state': old['state'], 'release': old['release'], 'managed_files': {}}
    files[managed / 'managed.json'] = encoded(next_manifest)
    for path in files:
        safe_profile_path(path, folder)
        if path not in (config, managed / 'managed.json') and path.exists() and str(path.relative_to(folder)) not in (old or {}).get('managed_files', {}):
            raise ValueError(f'Fichier préexistant non géré : {path}. Aucun écrasement ni adoption implicite.')
    extra = {'release': str(release) if release else (old or {}).get('release'), 'state': state}
    if reconciliation:
        extra['block_reconciled'] = reconciliation
    return files, extra, next_manifest


def plan(root, home, profile, project, action='install', delegate=False, agent_role='standard', output_resume=False, output_resume_project=None, codex_workspace_write=False, asi1_effort=False):
    if action not in ('install', 'remove') or type(delegate) is not bool or agent_role not in ('standard', 'coordinator') or type(output_resume) is not bool or type(codex_workspace_write) is not bool or type(asi1_effort) is not bool or (codex_workspace_write and not delegate):
        raise ValueError('Action ou capacité invalide.')
    if inspect(home, profile).get('pending_plan'):
        raise ValueError('Reprendre l’opération partielle conservée avant de créer un autre plan.')
    files, extra, _ = desired(root, home, profile, project, action, delegate, agent_role, output_resume, output_resume_project, codex_workspace_write, asi1_effort)
    changes = []
    for path, text in files.items():
        before, after = file_hash(path), digest(text.encode()) if text is not None else None
        if before != after:
            changes.append({'path': str(path), 'action': 'remove' if text is None else 'write',
                            'before_sha256': before, 'after_sha256': after})
    canonical_home, _, _ = context(home, profile)
    result = {'format': 1, 'action': action, 'home': str(canonical_home), 'profile': profile,
              'project': str(Path(project).expanduser().resolve(strict=True)), 'delegate': delegate,
              'changes': changes, **extra}
    if codex_workspace_write:
        result['codex_workspace_write'] = True
    if agent_role != 'standard':
        result['agent_role'] = agent_role
    if output_resume:
        result['output_resume'] = True
        result['output_resume_project'] = str(Path(output_resume_project or project).expanduser().resolve(strict=True))
    if asi1_effort and action == 'install':
        result['asi1_effort'] = True
    if 'block_reconciled' in extra:
        result['block_reconciled'] = extra['block_reconciled']
    result['fingerprint'] = digest(encoded(result).encode())
    return result


@contextmanager
def locked(managed):
    managed.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor = os.open(managed / 'lock', os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, 'a') as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError('Une opération d’intégration est déjà active.')
        yield


def apply(root, public):
    if not isinstance(public, dict) or public.get('format') != 1:
        raise ValueError('Plan incompatible.')
    unsigned = {k: v for k, v in public.items() if k != 'fingerprint'}
    if digest(encoded(unsigned).encode()) != public.get('fingerprint'):
        raise ValueError('Plan altéré ; refaire la prévisualisation.')
    _, folder, managed = context(public['home'], public['profile'])
    with locked(managed):
        journal_path = managed / 'operation.json'
        journal = read_journal(journal_path)
        if journal.get('status') == 'pending':
            if journal['plan'] != public:
                raise ValueError('Un autre plan est en attente ; reprendre ce plan sans écrasement.')
        else:
            current = plan(root, public['home'], public['profile'], public['project'], public['action'], public['delegate'], public.get('agent_role', 'standard'), public.get('output_resume', False), public.get('output_resume_project'), public.get('codex_workspace_write', False), public.get('asi1_effort', False))
            if current != public:
                raise ValueError('Entrées modifiées depuis la prévisualisation. Refaire le plan.')
            if not public['changes']:
                return {'status': 'completed', 'changed': False, 'message': 'Configuration identique ; aucune écriture.'}
            files, _, _ = desired(root, public['home'], public['profile'], public['project'], public['action'], public['delegate'], public.get('agent_role', 'standard'), public.get('output_resume', False), public.get('output_resume_project'), public.get('codex_workspace_write', False), public.get('asi1_effort', False))
            if public['action'] == 'install':
                helpers, runtime, _ = bundle_info(root)
                stage_release(helpers, runtime, Path(public['release']))
            backup = managed / 'backups' / str(uuid.uuid4())
            backup.mkdir(parents=True, mode=0o700)
            operations = []
            for change in public['changes']:
                path = Path(change['path'])
                if '..' in path.parts or not path.is_relative_to(folder):
                    raise ValueError('Destination hors du profil.')
                if path.exists():
                    saved = backup / path.relative_to(folder)
                    saved.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                    shutil.copyfile(path, saved)
                    saved.chmod(0o600)
                operations.append(change | {'text': files[path]})
            journal = {'format': 1, 'status': 'pending', 'plan': public, 'backup': str(backup), 'operations': operations}
            atomic(journal_path, encoded(journal))
        # The journal is local data, not an authority to introduce additional writes.
        if len(journal['operations']) != len(public['changes']):
            raise ValueError('Journal incohérent avec le plan.')
        if public['action'] == 'install':
            release_check(Path(public['release']))
        for operation, change in zip(journal['operations'], public['changes']):
            if any(operation.get(key) != value for key, value in change.items()):
                raise ValueError('Journal modifié ; réconciliation requise.')
            text = operation.get('text')
            if (text is not None and not isinstance(text, str)) or (digest(text.encode()) if text is not None else None) != change['after_sha256']:
                raise ValueError('Contenu du journal modifié ; aucune écriture.')
        # Validate the complete current set before continuing a partial operation.
        for operation in journal['operations']:
            safe_profile_path(Path(operation['path']), folder)
            current = file_hash(Path(operation['path']))
            if current not in (operation['before_sha256'], operation['after_sha256']):
                raise ValueError('Conflit après opération partielle ; sauvegardes conservées, aucune nouvelle écriture.')
        for operation in journal['operations']:
            path = Path(operation['path'])
            current = file_hash(path)
            if current == operation['after_sha256']:
                continue
            if current != operation['before_sha256']:
                raise ValueError('Conflit détecté avant écriture ; opération suspendue, sauvegarde conservée.')
            if operation['text'] is None:
                path.unlink(missing_ok=True)
                _sync_directory(path.parent)
            else:
                atomic(path, operation['text'])
        journal['status'] = 'completed'
        atomic(journal_path, encoded(journal))
    return {'status': 'completed', 'changed': True, 'backup': journal['backup'],
            'message': 'Configuration appliquée. Aucun client chargé ni service redémarré ; vérification séparée requise.'}


def bridge_capabilities(tools):
    """Report advertised input capabilities of the probed release, not the client."""
    schemas = {tool['name']: tool.get('inputSchema', {}) for tool in tools}
    def advertised(schema, field, value):
        field_schema = schema.get('properties', {}).get(field, {})
        if field_schema.get('const') == value or value in field_schema.get('enum', []):
            return True
        return any(advertised(branch, field, value)
                   for operator in ('oneOf', 'anyOf', 'allOf')
                   for branch in schema.get(operator, []))
    def supports(name, field, value):
        return advertised(schemas.get(name, {}), field, value)
    return {'result_transport': {
        'receipt': supports('reprise_requests', 'view', 'receipt'),
        'pagination': supports('reprise_requests', 'view', 'page'),
        'delegate_receipt': supports('reprise_delegate', 'return_mode', 'receipt') if 'reprise_delegate' in schemas else None,
        'followup_receipt': supports('reprise_followup', 'return_mode', 'receipt') if 'reprise_followup' in schemas else None,
    }, 'evidence': 'direct_probe_tools_schema', 'client_loaded': 'unknown'}


def verify(home, profile, root=None):
    _, folder, managed = context(home, profile)
    if inspect(home, profile).get('pending_plan'):
        raise ValueError('Opération partielle : terminer ou réconcilier avant vérification.')
    old = manifest(managed)
    if not old or old.get('status') != 'installed':
        raise ValueError('Aucune intégration installée gérée dans ce profil.')
    config_text = (folder / 'cordis.patch.yml').read_bytes().decode('utf-8')
    base, block = split_block(config_text)
    reconciled = None
    if block is None or digest(block.encode()) != old['block_sha256']:
        expected = _bridge_entries(Path(old['release']), old['state'], old['tools'], old['project'],
                                   old['profile'], managed, old.get('output_resume', False),
                                   old.get('output_resume_project'), old.get('codex_workspace_write', False))
        if block is None or block_entries(block) != expected:
            raise ValueError('Configuration Reprise absente ou modifiée.')
        # Bloc reformatté équivalent : accepté sans réécriture ici.
        reconciled = digest(block.encode())
    if old.get('asi1_effort'):
        checked, _, _ = apply_asi1_effort(base, old, True)
        if checked != base:
            raise ValueError('Configuration ASI1 gérée absente ou modifiée.')
        checked, _, _ = apply_asi1_preset(base, old, True, str(managed / 'plugins' / ASI1_PLUGIN))
        if checked != base:
            raise ValueError('Preset ASI1 géré absent ou modifié.')
    for relative, expected in old['managed_files'].items():
        safe_profile_path(folder / relative, folder)
        if file_hash(folder / relative) != expected:
            raise ValueError('Consignes installées absentes ou modifiées.')
    release = Path(old['release'])
    selected_state = state_location(root or Path(__file__).parent).resolve()
    expected_base = selected_state.parent / 'integration-releases'
    if (Path(old['state']).resolve() != selected_state or not re.fullmatch(r'[a-f0-9]{64}', release.name)
            or release.is_symlink() or expected_base.is_symlink() or release.parent.resolve() != expected_base.resolve()):
        raise ValueError('Release ou état hors de l’installation Reprise sélectionnée ; aucune exécution.')
    release_check(release)
    requests = [{'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {}},
                {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
                {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list', 'params': {}}]
    with tempfile.TemporaryDirectory(prefix='reprise-bridge-check-') as temporary:
        program = release / 'Contents/Resources/runtime/bin/python3'
        command = [str(program), '-E', '-s', '-B', str(release / 'Contents/Resources/helpers/codex_expert_mcp.py'),
                   '--project-root', old['project'], '--state', temporary, '--tools', ','.join(old['tools'])]
        env = {k: v for k, v in os.environ.items() if not k.startswith(('PYTHON', 'DYLD_')) and k != 'AGENT_RESUME_STATE'}
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        response = subprocess.run(command, input='\n'.join(json.dumps(r) for r in requests) + '\n',
                                  capture_output=True, text=True, timeout=20, env=env, check=True)
    messages = [json.loads(line) for line in response.stdout.splitlines()]
    initialized_reply = next(m['result'] for m in messages if m.get('id') == 1)
    tools = next(m['result']['tools'] for m in messages if m.get('id') == 2)
    names = sorted(tool['name'] for tool in tools)
    if names != sorted(old['tools']):
        raise ValueError('Outils observés différents de la sélection installée.')
    selected_release = {'status': 'unknown', 'reason': 'selected_bundle_not_available'}
    try:
        _, _, identity = bundle_info(root or Path(__file__).parent)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        selected_release['reason'] = 'selected_bundle_unavailable_or_invalid'
    else:
        selected_release = {'status': 'current' if identity == release.name else 'outdated',
                            'configured_identity': release.name, 'selected_identity': identity}
    capabilities = bridge_capabilities(tools)
    transport = capabilities['result_transport']
    missing = [name for name, available in transport.items() if available is False]
    update_required = selected_release['status'] == 'outdated' or bool(missing)
    message = 'Bloc géré et consignes vérifiés ; pont sondé directement sans inférence. Chargement par Harness non observé.'
    if update_required:
        message += ' Mise à jour de l’intégration requise ; rechargement du client à coordonner séparément.'
    result = {'status': 'verified', 'message': message,
            'selected_release': selected_release, 'update_required': update_required,
            'bridge_capabilities': capabilities, 'missing_result_capabilities': missing,
            'output_resume': {'configured': old.get('output_resume', False), 'client_loaded': 'unknown'},
            'asi1_effort': {'configured': old.get('asi1_effort', False), 'client_loaded': 'unknown'},
            'levels': {'configuration_written': True, 'integration_loaded': 'unknown', 'client_tools_discovered': 'unknown', 'exchange_confirmed': 'unknown'},
            'full_profile_syntax': 'not_checked', 'bridge_tools': names, 'bridge_version': initialized_reply['serverInfo']['version'],
            'bridge_source_sha256': initialized_reply['serverInfo'].get('source_sha256')}
    if reconciled:
        result['block_reconciled'] = reconciled
    return result


def main(root, argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    for name in ('integration-inspect', 'integration-plan', 'integration-verify'):
        command = sub.add_parser(name)
        command.add_argument('--home', required=True)
        command.add_argument('--profile', required=name != 'integration-inspect')
        if name == 'integration-plan':
            command.add_argument('--project', required=True)
            command.add_argument('--action', choices=('install', 'remove'), required=True)
            command.add_argument('--delegate', action='store_true')
            command.add_argument('--output-resume-project', help='Explicit project for native continuation; defaults to bridge project')
            command.add_argument('--output-resume', action='store_true', help='Explicitly authorize same-session continuation after output-token limit')
            command.add_argument('--asi1-effort', action='store_true', help='Installer l’effort ASI1 bas pour le preset asi1-orchestrator')
            command.add_argument('--codex-workspace-write', action='store_true', help='Autoriser les implémentations Codex dans le projet sélectionné')
            command.add_argument('--agent-role', choices=('standard', 'coordinator'), default='standard')
    sub.add_parser('integration-apply')
    args = parser.parse_args(argv)
    os.umask(0o077)
    try:
        if args.command == 'integration-inspect':
            result = inspect(args.home, args.profile)
        elif args.command == 'integration-plan':
            result = {'status': 'planned', 'message': 'Plan sans écriture. L’installation n’autorise ni inférence ni activation automatique.',
                      'plan': plan(root, args.home, args.profile, args.project, args.action, args.delegate, args.agent_role, args.output_resume, args.output_resume_project, args.codex_workspace_write, args.asi1_effort)}
        elif args.command == 'integration-apply':
            public = json.loads(sys.stdin.read(1024 * 1024))['plan']
            result = apply(root, public)
        else:
            result = verify(args.home, args.profile, root=root)
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        result = {'status': 'refused', 'message': str(error), 'recovery': 'Aucune suppression automatique. Inspecter le profil pour retrouver un plan partiel ou les sauvegardes.'}
        if args.command == 'integration-apply' and isinstance(locals().get('public'), dict):
            try:
                evidence = inspect(public['home'], public['profile'])
                for key in ('pending_plan', 'backup'):
                    if key in evidence:
                        result[key] = evidence[key]
            except (OSError, ValueError, KeyError, TypeError):
                pass
        print(json.dumps(result, ensure_ascii=False))
        return 1
    print(json.dumps(result, ensure_ascii=False))
    return 0
